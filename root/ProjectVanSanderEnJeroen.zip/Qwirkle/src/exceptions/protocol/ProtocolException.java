package exceptions.protocol;

public class ProtocolException extends Exception {

	public String getMessage() {
		return "ProtocolException : ";
	}
}
