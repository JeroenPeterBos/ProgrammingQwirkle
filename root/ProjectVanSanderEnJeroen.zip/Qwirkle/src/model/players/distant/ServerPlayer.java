package model.players.distant;

import model.game.Game;
import model.players.Player;

public class ServerPlayer extends Player{

	public ServerPlayer(String n, Game g) {
		super(n, g);
	}
}
