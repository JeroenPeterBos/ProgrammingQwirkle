package network.commands;

import model.components.move.Move;

public interface GameCommand {

	public Move getMove();
}
