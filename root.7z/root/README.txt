Voor het draaien van een locale demonstratie moet u 'controller.LocalController' uitvoeren.
Voor het starten van een server moet u 'server.Server' uitvoeren.
Voor het starten van een client moet u 'controller.Client' uitvoeren.


Het uitvoeren van deze programmas kunt u doen direct vanuit eclipse of van uit de opdrachtprompt met de commandos 'javac' en 'javaw'